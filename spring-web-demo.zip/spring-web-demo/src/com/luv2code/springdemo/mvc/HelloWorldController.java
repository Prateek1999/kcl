package com.luv2code.springdemo.mvc;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {
	
	@RequestMapping("/showform")
	public String showForm() {
		return "form-page";
	}
	
	@RequestMapping("/processForm")
	public String processform() {
		return "Hellospring";
	}
	
	@RequestMapping("/processFormversion2")
	public String processformv2(HttpServletRequest request,Model model) {
		String thename= request.getParameter("studentName");
		thename=thename.toUpperCase();
		String result="yo"+ thename;
		model.addAttribute( "message", result);
		return "Hellospring";
	}


}

package com.mykcl.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanScopeDemoApp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("scopeDemo-ApplicationContext.xml");
		Coach thecoach= context.getBean("myCoach",Coach.class);
		Coach alphacoach= context.getBean("myCoach",Coach.class);
		boolean result= thecoach==alphacoach;
		System.out.println("pointing"+result);
		System.out.println("location"+thecoach);
		System.out.println("location"+alphacoach);
		context.close();
	}

}

package com.mykcl.springdemo;

public interface FortuneService {
	public String getFortune();
}

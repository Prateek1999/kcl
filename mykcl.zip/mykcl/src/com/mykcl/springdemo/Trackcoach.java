package com.mykcl.springdemo;

public class Trackcoach implements Coach {

	private FortuneService fortuneservice;
	public Trackcoach() {}
	
	public Trackcoach(FortuneService thefortuneservice) {
		
		 fortuneservice=thefortuneservice;
	}

	@Override
	public String getDailyWorkout() {
		return "trackout for 30 minutes";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return "this is new"+ fortuneservice.getFortune();
	}
	
	//init method
	public void doMyStartupStuff() {
		System.out.println("initmethodinitmethodinitmethod");
	}
	
	//destroy method
	//init method
		public void doMyCleanupStuff() {
			System.out.println("destorymethoddestorymethod");
		}

}

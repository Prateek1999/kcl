package com.mykcl.springdemo;

public class CricketCoach implements Coach {

	private FortuneService fortuneservice;
	
	public CricketCoach() {
		System.out.println("Cricket:insideConstructor");
	}

	public void setFortuneservice(FortuneService fortuneservice) {
		System.out.println("Cricket:insidersetter");
		this.fortuneservice = fortuneservice;
	}

	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "BowlingBowlingBowling";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneservice.getFortune();
	}

}

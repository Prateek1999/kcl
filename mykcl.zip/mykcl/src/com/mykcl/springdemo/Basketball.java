package com.mykcl.springdemo;

public class Basketball implements Coach {
	private FortuneService fortuneservice;
	Basketball(FortuneService thefortuneservice){
		fortuneservice = thefortuneservice;
	}
	
	@Override
	public String getDailyWorkout() {
		return "Workout for 30 minutes";
	}

	@Override
	public String getDailyFortune() {
		// TODO Auto-generated method stub
		return fortuneservice.getFortune();
	}

}

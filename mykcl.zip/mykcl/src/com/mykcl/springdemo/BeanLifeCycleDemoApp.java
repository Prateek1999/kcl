package com.mykcl.springdemo;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanLifeCycleDemoApp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("LifeCycleDemo-ApplicationContext2.xml");
		Coach thecoach= context.getBean("myCoach",Coach.class);
		System.out.println(thecoach.getDailyWorkout());
		
		
		context.close();
	}

}

package com.mykcl.springdemo;

public class Myapp {
	public static void main(String[] args) {
		Coach b=new Trackcoach();
		System.out.println(b.getDailyWorkout());
	}
}

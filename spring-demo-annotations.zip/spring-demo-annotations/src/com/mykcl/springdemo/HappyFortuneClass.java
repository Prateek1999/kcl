package com.mykcl.springdemo;

import org.springframework.stereotype.Component;

@Component
public class HappyFortuneClass implements FortuneService {

	@Override
	public String getFortune() {
		// TODO Auto-generated method stub
		return "Today is your lucky day";
	}

}
